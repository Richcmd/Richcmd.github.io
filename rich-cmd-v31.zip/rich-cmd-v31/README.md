# RICH CMD v3.1

Your Personal Retail Intelligence Command Center.

## Starten
Open `index.html` in je browser of upload de volledige map naar GitHub Pages.

## Belangrijkste verbeteringen in v3.1
- Live Assist hover panel op desktop voor shift, pauze, werkdruk, productiviteit en volgende taak.
- Hamburger menu werkt alleen op kleinere schermen en blokkeert desktop niet meer.
- Dashboardbegroeting toont weer persoonlijke groet + advies in plaats van dubbele branding.
- Shiftlogboek voor inklokken, pauzes en afgesloten shifts.
- Uitgebreider opleidingssysteem: werkhouding, communicatie, management, AGF en HACCP.
- HACCP toont minder taken standaard en heeft een "laat meer zien" optie.
- AGF Quick Check voor snelle dagelijkse productchecks.
- Productbeheer met product verwijderen.
- Betere dropdown styling.
- Visualisatie met KPI overzicht, werkdruk vs uren, AGF verdeling en communicatiegrafiek.
- Communicatie heeft "alles als gelezen" en duidelijke statuskleuren.
- Diagnostiek is uitgebreid met datakwaliteit, dubbele producten, ontbrekende gegevens, openstaande/uitgestelde taken en module-aantallen.

## Opslag
Alle data wordt lokaal opgeslagen in de browser via localStorage.
